package com.mega.mvcProjectTest;

public class ScommentVO {
	private String code;
	private String scpw;
	private String scomment;
	private int srecommen;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getScpw() {
		return scpw;
	}
	public void setScpw(String scpw) {
		this.scpw = scpw;
	}
	public String getScomment() {
		return scomment;
	}
	public void setScomment(String scomment) {
		this.scomment = scomment;
	}
	public int getSrecommen() {
		return srecommen;
	}
	public void setSrecommen(int srecommen) {
		this.srecommen = srecommen;
	}
}
