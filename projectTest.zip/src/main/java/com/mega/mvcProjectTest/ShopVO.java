package com.mega.mvcProjectTest;

public class ShopVO {
	private String code;
	private String name;
	private String sksc;
	private String pksc;
	private int price;
	private String content;
	private int lkup;
	private int pstock;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSksc() {
		return sksc;
	}
	public void setSksc(String sksc) {
		this.sksc = sksc;
	}
	public String getPksc() {
		return pksc;
	}
	public void setPksc(String pksc) {
		this.pksc = pksc;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getLkup() {
		return lkup;
	}
	public void setLkup(int lkup) {
		this.lkup = lkup;
	}
	public int getPstock() {
		return pstock;
	}
	public void setPstock(int pstock) {
		this.pstock = pstock;
	}
}
